from flask import Flask, render_template, request, redirect, jsonify
from readsensor import SensorReader
import os

app = Flask(__name__)
sensor = SensorReader()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        uname = request.form['username']
        pwd = request.form['password']
        with open('users.txt') as f:
            for line in f:
                u, p = line.strip().split(':')
                if uname == u and pwd == p:
                    return redirect('/dashboard')
        return render_template('login.html', error="Invalid Credentials")
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/get_data')
def get_data():
    temp, power = sensor.read_data()
    return jsonify({'temperature': temp, 'power': power})

@app.route('/save_data', methods=['POST'])
def save_data():
    temp, power = sensor.read_data()
    sensor.save_data(temp, power)
    return '', 204

@app.route('/view_data')
def view_data():
    with open('data.txt') as f:
        lines = [line.strip().split(',') for line in f.readlines()]
    return render_template('data.html', records=lines)

if __name__ == '__main__':
    if not os.path.exists("users.txt"):
        with open("users.txt", "w") as f:
            f.write("admin:admin122\n")
    if not os.path.exists("data.txt"):
        open("data.txt", "w").close()
    app.run(debug=True)
