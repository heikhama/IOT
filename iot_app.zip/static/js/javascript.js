setInterval(() => {
    fetch('/get_data')
    .then(response => response.json())
    .then(data => {
        document.getElementById("temp").value = data.temperature + " °C";
        document.getElementById("power").value = data.power + " W";
        updateGraph(data);
        fetch('/save_data', { method: 'POST' });
    });
}, 1000);

function saveManual() {
    fetch('/save_data', { method: 'POST' });
}
