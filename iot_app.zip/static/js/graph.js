let labels = [], tempData = [], powerData = [];
let chart = new Chart(document.getElementById("chart"), {
    type: 'line',
    data: {
        labels: labels,
        datasets: [
            { label: 'Temperature (°C)', data: tempData, borderColor: 'red', fill: false },
            { label: 'Power (W)', data: powerData, borderColor: 'blue', fill: false }
        ]
    },
    options: {
        animation: false,
        scales: {
            x: { title: { display: true, text: "Time" }},
            y: { title: { display: true, text: "Value" }}
        }
    }
});

function updateGraph(data) {
    let time = new Date().toLocaleTimeString();
    if (labels.length > 20) {
        labels.shift();
        tempData.shift();
        powerData.shift();
    }
    labels.push(time);
    tempData.push(data.temperature);
    powerData.push(data.power);
    chart.update();
}
