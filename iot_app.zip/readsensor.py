import random
from datetime import datetime

class SensorReader:
    def read_data(self):
        temp = round(random.uniform(30.0, 60.0), 2)
        power = round(random.uniform(5.0, 20.0), 2)
        return temp, power

    def save_data(self, temperature, power):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open("data.txt", "a") as f:
            f.write(f"{now},{temperature},{power}\n")
